package principal;

public class Principal {

	public static void main(String[] args) {
		
		Foro f1 = new Foro(1000);
		Thread puerta1 = new Thread(new Prueba1('A',f1), "Puerta 1 " ); 
		Thread puerta2 = new Thread(new Prueba1('B',f1), "Puerta 2"); 
		
		puerta1.start();
		puerta2.start();

		
	}
	
}
