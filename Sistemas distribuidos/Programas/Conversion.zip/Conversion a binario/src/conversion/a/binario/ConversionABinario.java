/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conversion.a.binario;

import javax.swing.JOptionPane;

/**
 *
 * @author Alumno
 */
public class ConversionABinario {

    public static void main(String[] args) {

        //que sea entre 0/255 
        // que sea num
        //rellenar
        boolean pan = true;
        while (pan) {
            try {
                String ip = JOptionPane.showInputDialog("Ingresa el numero a convertir en binario");
                String[] ipArray = ip.split(".", 4);
                
                for(int i; i<4;i++){
                
                }
                
                pan = false;
                
            } catch (Exception e) {
                pan = true;
            } finally {
            }
        }

        

        JOptionPane.showMessageDialog(null, "el numerillo es " + res);

// TODO code application logic here
    }
    
    public String binario(int a){
        int num = a;
        String res = "";
        while (num != 0 && num != 1) {
            res = Integer.toString(num % 2) + res;
            num = num / 2;
            System.out.println(num);
        }
        res = num + res;

        //rellenar octeto de ip
        while (res.length() != 8) {
            res = 0 + res;
        }
        return res;
    }
}

//pedir numero entre 0-255 #si es mayor o menor regresar
//
